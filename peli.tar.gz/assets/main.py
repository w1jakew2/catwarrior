# -*- coding: utf-8 -*-
import pygame
import asyncio
import platform
import json
import urllib.request
import urllib.parse

from resources import lataa_resurssit, luo_tasanteet
from player import Pelaaja
from enemy import Vihollinen, Drone, Boss
from bullets import paivita_luotit
from ui import (
    piirra_valikko,
    piirra_ui,
    piirra_gameover,
    piirra_boss_hp,
    piirra_tasonousu,
    piirra_footer,
)

# --- PELITILAT ---
PELITILA_VALIKKO = "VALIKKO"
PELITILA_PELI = "PELI"
PELITILA_GAMEOVER = "GAMEOVER"


# --- TULOSTEN LATAUS (PHP) ---
def lataa_pisteet():
    url = "https://jaher.arkku.net/hae_pisteet.php"
    try:
        data = urllib.request.urlopen(url).read().decode("utf-8")
        return json.loads(data)
    except Exception as e:
        print("Virhe pisteiden latauksessa:", e)
        return []


# --- TULOSTEN TALLENNUS (PHP) ---
def tallenna_pisteet(nimi, pisteet, taso):
    if not nimi:
        nimi = "Player"

    params = urllib.parse.urlencode({"nimi": nimi, "pisteet": pisteet, "taso": taso})
    url = "https://jaher.arkku.net/tallenna.php?" + params

    try:
        urllib.request.urlopen(url)
        print("Pisteet tallennettu:", nimi, pisteet, taso)
    except Exception as e:
        print("Tallennusvirhe:", e)


# --- ASYNK MAIN ---
async def main():
    pygame.init()
    pygame.mixer.init()

    pygame.event.set_allowed([pygame.KEYDOWN, pygame.KEYUP, pygame.QUIT])

    naytto = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Cat Warrior: Ultimate Edition")
    kello = pygame.time.Clock()

    resurssit = lataa_resurssit()
    tasanteet = luo_tasanteet()

    top_lista = lataa_pisteet()

    # --- NIMEN SYÖTTÖ ---
    p_nimi = ""
    kirjaudu = True
    fontti_otsikko = pygame.font.SysFont("Arial", 52, bold=True)
    fontti_ohje = pygame.font.SysFont("Arial", 32, bold=True)
    fontti_kentta = pygame.font.SysFont("Arial", 20, bold=True)

    while kirjaudu:
        naytto.blit(resurssit["tausta"], (0, 0))

        ots = fontti_otsikko.render("CAT WARRIOR", True, (255, 255, 255))
        naytto.blit(ots, (400 - ots.get_width() // 2, 80))

        ohje = fontti_ohje.render("Anna nimimerkki:", True, (255, 255, 0))
        naytto.blit(ohje, (400 - ohje.get_width() // 2, 180))

        t = fontti_kentta.render(p_nimi + "_", True, (255, 255, 0))
        naytto.blit(t, (400 - t.get_width() // 2, 260))

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                return

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    kirjaudu = False
                    pelitila = PELITILA_PELI   # <-- TÄRKEÄ KORJAUS
                elif event.key == pygame.K_BACKSPACE:
                    p_nimi = p_nimi[:-1]
                elif event.unicode and event.unicode.isalnum() and len(p_nimi) < 10:
                    p_nimi += event.unicode

        piirra_footer(naytto)
        pygame.display.flip()
        await asyncio.sleep(0.01)
        kello.tick(60)

    # --- PELIN ALUSTUS ---
    pisteet = 0
    taso = 1

    pelaaja = Pelaaja(400, 495, resurssit["hahmo_o"], resurssit["hahmo_v"], resurssit["hyppy"])
    vihu = Vihollinen(resurssit["vihu"])
    drone = Drone(resurssit["drone"])
    viholliset = [vihu, drone]

    luodit = []
    kolikot = []

    gameover_tallennettu = False
    palaa_valikosta = False
    gameover_alku = 0

    tasonousu_teksti = ""
    tasonousu_ajastin = 0
    boss = None
    peli_valmis = False

    # --- PELILOOPPI ---
    while True:
        nyt = pygame.time.get_ticks()
        events = pygame.event.get()

        for event in events:
            if event.type == pygame.QUIT:
                return

        # --- VALIKKO (EI OHJAA PELIÄ) ---
        if pelitila == PELITILA_VALIKKO:
            piirra_valikko(naytto, resurssit["tausta"], top_lista)
            piirra_footer(naytto)

            pygame.display.flip()
            await asyncio.sleep(0.01)
            kello.tick(60)
            continue

        # --- PELI ---
        if pelitila == PELITILA_PELI:
            naytto.blit(resurssit["tausta"], (0, 0))

            if pelaaja.elamat <= 0:
                pelaaja.rect.x = -9999
                pelaaja.rect.y = -9999

            pelaaja.paivita(tasanteet)
            vihu.paivita()
            drone.paivita()
            if boss:
                boss.paivita()

            # Törmäykset
            if (
                vihu.elossa
                and pelaaja.rect.colliderect(vihu.rect)
                and nyt > pelaaja.kuolema_cd
                and pelaaja.elamat > 0
            ):
                pelaaja.elamat -= 1
                pelaaja.respawn()
                pelaaja.kuolema_cd = nyt + 1500
                if resurssit["osuma"]:
                    resurssit["osuma"].play()

            if (
                drone.elossa
                and pelaaja.rect.colliderect(drone.rect)
                and nyt > pelaaja.kuolema_cd
                and pelaaja.elamat > 0
            ):
                pelaaja.elamat -= 1
                pelaaja.respawn()
                pelaaja.kuolema_cd = nyt + 1500
                if resurssit["osuma"]:
                    resurssit["osuma"].play()

            # Luodit
            luodit, pisteet = paivita_luotit(luodit, pelaaja, viholliset, boss, resurssit, pisteet)

            # Boss kuolee
            if boss and boss.hp <= 0 and not peli_valmis:
                boss = None
                peli_valmis = True
                tasonousu_teksti = "Onnittelut! Olet pelannut pelin loppuun."
                tasonousu_ajastin = nyt + 4000
                gameover_alku = nyt
                pelitila = PELITILA_GAMEOVER

            # Kolikot
            if not vihu.elossa:
                kolikot.append(pygame.Rect(vihu.rect.x, vihu.rect.y, 30, 30))
                vihu.respawn()

            if not drone.elossa:
                kolikot.append(pygame.Rect(drone.rect.x, drone.rect.y, 30, 30))
                drone.respawn()

            for kolikko in kolikot[:]:
                if pelaaja.rect.colliderect(kolikko):
                    kolikot.remove(kolikko)
                    pisteet += 10
                    if resurssit["kolikko"]:
                        resurssit["kolikko"].play()

            # Tason nousu
            if taso == 1 and pisteet >= 200:
                taso = 2
                tasonousu_teksti = "Taso 2!"
                tasonousu_ajastin = nyt + 2000

            elif taso == 2 and pisteet >= 300:
                taso = 3
                tasonousu_teksti = "Taso 3!"
                tasonousu_ajastin = nyt + 2000

            elif taso == 3 and pisteet >= 400:
                taso = 4
                tasonousu_teksti = "Taso 4!"
                tasonousu_ajastin = nyt + 2000

            elif taso == 4 and pisteet >= 500 and boss is None:
                taso = 5
                tasonousu_teksti = "Taso 5 – Big Boss!"
                tasonousu_ajastin = nyt + 2000
                boss_sprite = resurssit.get("boss", resurssit["vihu"])
                boss = Boss(boss_sprite)

            # Piirto
            pelaaja.piirra(naytto)
            vihu.piirra(naytto)
            drone.piirra(naytto)

            for luoti in luodit:
                luoti.piirra(naytto)

            for tr in tasanteet:
                pygame.draw.rect(naytto, (120, 80, 40), tr)

            for kolikko in kolikot:
                pygame.draw.circle(naytto, (255, 215, 0), kolikko.center, 15)

            if boss:
                boss.piirra(naytto)
                piirra_boss_hp(naytto, boss)

            piirra_ui(naytto, pisteet, pelaaja.elamat, taso)

            if tasonousu_teksti and nyt < tasonousu_ajastin:
                piirra_tasonousu(naytto, tasonousu_teksti)
            elif tasonousu_teksti and nyt >= tasonousu_ajastin:
                tasonousu_teksti = ""

            # GAME OVER tallennus
            if pelaaja.elamat <= 0 and not gameover_tallennettu:
                tallenna_pisteet(p_nimi, pisteet, taso)
                top_lista = lataa_pisteet()
                gameover_tallennettu = True
                gameover_alku = nyt
                pelitila = PELITILA_GAMEOVER

            if peli_valmis and not gameover_tallennettu:
                tallenna_pisteet(p_nimi, pisteet, taso)
                top_lista = lataa_pisteet()
                gameover_tallennettu = True
                gameover_alku = nyt
                pelitila = PELITILA_GAMEOVER

            piirra_footer(naytto)
            pygame.display.flip()
            await asyncio.sleep(0.01)
            kello.tick(60)

        # --- GAME OVER ---
        if pelitila == PELITILA_GAMEOVER:
            piirra_gameover(naytto, resurssit["tausta"], p_nimi, pisteet, taso)
            piirra_footer(naytto)

            if pygame.time.get_ticks() - gameover_alku > 2000:
                pelitila = PELITILA_VALIKKO
                p_nimi = ""
                kirjaudu = True
                return await main()  # <-- PALAUTUS KIRJAUTUMISEEN

            pygame.display.flip()
            await asyncio.sleep(0.01)
            kello.tick(60)


# --- WASM ---
if platform.system() == "Emscripten":
    asyncio.ensure_future(main())
else:
    asyncio.run(main())
