import pygame
import random

# ---------------------------------------------------------
# PERUS VIHOLLINEN (Taso 1)
# ---------------------------------------------------------
class Vihollinen:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(0, 490, 50, 60)
        self.suunta = 1
        self.elossa = True
        self.nopeus = 4

    def paivita(self):
        if not self.elossa:
            self.rect.x = -200
            return

        self.rect.x += self.nopeus * self.suunta

        if self.rect.x < 0 or self.rect.x > 750:
            self.suunta *= -1

    def respawn(self):
        self.rect.x = random.randint(0, 700)
        self.rect.y = 490
        self.suunta = random.choice([-1, 1])
        self.elossa = True

    def piirra(self, naytto):
        if self.elossa:
            naytto.blit(self.kuva, self.rect.topleft)


# ---------------------------------------------------------
# DRONE (Taso 1)
# ---------------------------------------------------------
class Drone:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(700, 100, 45, 45)
        self.suunta = -1
        self.elossa = True
        self.nopeus = 3

    def paivita(self):
        if not self.elossa:
            self.rect.x = -200
            return

        self.rect.x += self.nopeus * self.suunta

        if self.rect.x < 0 or self.rect.x > 750:
            self.suunta *= -1

    def respawn(self):
        self.rect.x = random.randint(100, 700)
        self.rect.y = random.randint(50, 200)
        self.suunta = random.choice([-1, 1])
        self.elossa = True

    def piirra(self, naytto):
        if self.elossa:
            naytto.blit(self.kuva, self.rect.topleft)


# ---------------------------------------------------------
# SHADOW CAT – Nopea vihollinen (Taso 2)
# ---------------------------------------------------------
class ShadowCat:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(random.randint(0, 700), 490, 50, 50)
        self.nopeus = 7
        self.suunta = random.choice([-1, 1])
        self.elossa = True
        self.hp = 2

    def paivita(self, pelaaja):
        if not self.elossa:
            self.rect.x = -200
            return

        # Hyökkää pelaajaa kohti, jos samalla korkeudella
        if abs(self.rect.y - pelaaja.rect.y) < 40:
            if pelaaja.rect.x < self.rect.x:
                self.suunta = -1
            else:
                self.suunta = 1

        self.rect.x += self.nopeus * self.suunta

        if self.rect.x < 0 or self.rect.x > 750:
            self.suunta *= -1

    def ota_osuma(self):
        self.hp -= 1
        if self.hp <= 0:
            self.elossa = False

    def respawn(self):
        self.rect.x = random.randint(0, 700)
        self.rect.y = 490
        self.suunta = random.choice([-1, 1])
        self.hp = 2
        self.elossa = True

    def piirra(self, naytto):
        if self.elossa:
            naytto.blit(self.kuva, self.rect.topleft)


# ---------------------------------------------------------
# ARMORED HOUND – Panssaroitu vihollinen (Taso 3)
# ---------------------------------------------------------
class ArmoredHound:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(random.randint(0, 700), 490, 60, 60)
        self.nopeus = 2
        self.suunta = random.choice([-1, 1])
        self.elossa = True
        self.hp = 5

    def paivita(self):
        if not self.elossa:
            self.rect.x = -200
            return

        self.rect.x += self.nopeus * self.suunta

        if self.rect.x < 0 or self.rect.x > 740:
            self.suunta *= -1

    def ota_osuma(self):
        self.hp -= 1
        if self.hp <= 0:
            self.elossa = False

    def respawn(self):
        self.rect.x = random.randint(0, 700)
        self.rect.y = 490
        self.suunta = random.choice([-1, 1])
        self.hp = 5
        self.elossa = True

    def piirra(self, naytto):
        if self.elossa:
            naytto.blit(self.kuva, self.rect.topleft)


# ---------------------------------------------------------
# MECHA MOUSE – Räjähtävä vihollinen (Taso 4)
# ---------------------------------------------------------
class MechaMouse:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(random.randint(0, 700), 490, 40, 40)
        self.nopeus = 5
        self.elossa = True

    def paivita(self, pelaaja):
        if not self.elossa:
            self.rect.x = -200
            return

        # Kulkee suoraan pelaajaa kohti
        if pelaaja.rect.x < self.rect.x:
            self.rect.x -= self.nopeus
        else:
            self.rect.x += self.nopeus

        if self.rect.x < 0 or self.rect.x > 760:
            self.elossa = False

    def ota_osuma(self):
        # Räjähtää heti
        self.elossa = False

    def piirra(self, naytto):
        if self.elossa:
            naytto.blit(self.kuva, self.rect.topleft)


# ---------------------------------------------------------
# BOSS – Monivaiheinen pomo (Taso 5)
# ---------------------------------------------------------
class Boss:
    def __init__(self, kuva):
        self.kuva = kuva
        self.rect = pygame.Rect(300, 100, 200, 200)
        self.hp = 20
        self.nopeus = 2
        self.vaihe = 1  # 1 = hidas, 2 = ampuva, 3 = aggressiivinen

    def paivita(self):
        # Vaiheiden logiikka
        if self.hp > 10:
            self.vaihe = 1
            self.nopeus = 2
        elif self.hp > 5:
            self.vaihe = 2
            self.nopeus = 3
        else:
            self.vaihe = 3
            self.nopeus = 4

        # Liike
        self.rect.x += self.nopeus
        if self.rect.x < 0 or self.rect.x > 600:
            self.nopeus *= -1

    def ota_osuma(self):
        self.hp -= 1

    def piirra(self, naytto):
        naytto.blit(self.kuva, self.rect.topleft)
