import pygame

class Luoti:
    def __init__(self, x, y, vx, vy):
        self.rect = pygame.Rect(x, y, 10, 10)
        self.vx = vx
        self.vy = vy

    def paivita(self):
        self.rect.x += self.vx
        self.rect.y += self.vy

    def piirra(self, naytto):
        pygame.draw.rect(naytto, (255, 0, 0), self.rect)


def paivita_luotit(luodit, pelaaja, viholliset, boss, resurssit, pisteet):
    keys = pygame.key.get_pressed()
    aika = pygame.time.get_ticks()

    # --- Ampuminen cooldownilla ---
    if keys[pygame.K_f] and aika > pelaaja.tuli_cd:
        vx = 15 * pelaaja.katse
        vy = -15 if keys[pygame.K_UP] else 0

        # Normaali luoti
        luodit.append(Luoti(pelaaja.rect.centerx, pelaaja.rect.centery, vx, vy))

        # Tuplaluoti tasolla 5
        if pelaaja.tuplaluoti:
            luodit.append(Luoti(pelaaja.rect.centerx, pelaaja.rect.centery - 10, vx, vy))

        pelaaja.tuli_cd = aika + 250

        if resurssit["tuli"]:
            resurssit["tuli"].play()

    # --- Päivitä luodit ---
    for luoti in luodit[:]:
        luoti.paivita()

        # --- Osuma bossiin ---
        if boss:
            if luoti.rect.colliderect(boss.rect):
                boss.ota_osuma()
                luodit.remove(luoti)
                continue

        # --- Osuma vihollisiin ---
        for v in viholliset:
            if v.elossa and luoti.rect.colliderect(v.rect):

                # ShadowCat ja ArmoredHound käyttävät HP:tä
                if hasattr(v, "hp"):
                    v.ota_osuma()
                    if not v.elossa:
                        pisteet += 20
                else:
                    # Perusvihollinen ja drone
                    v.elossa = False
                    pisteet += 10

                luodit.remove(luoti)
                break

        # --- Poista ruudun ulkopuolelle menneet ---
        if (luoti.rect.x < 0 or luoti.rect.x > 800 or
            luoti.rect.y < 0 or luoti.rect.y > 600):
            luodit.remove(luoti)

    return luodit, pisteet
