import pygame

class Pelaaja:
    """
    Pelaajahahmo: liikkuminen, hyppy, tuplahyppy, fysiikka, törmäykset ja elämät.
    """

    def __init__(self, x, y, kuva_o, kuva_v, hyppy_aani):
        # Sijainti ja fysiikka
        self.rect = pygame.Rect(x, y, 55, 55)
        self.vy = 0
        self.ilmassa = False
        self.katse = 1
        self.elamat = 3
        self.kuolema_cd = 0

        # Liikkumisnopeus (perus)
        self.nopeus = 7

        # Hyppyominaisuudet
        self.tuplahyppy = False          # aktivoituu tasolla 3
        self.tuplahyppy_kaytetty = False

        # Ampumisominaisuudet
        self.tuplaluoti = False          # aktivoituu tasolla 5
        self.tuli_cd = 0

        # Spritet
        self.kuva_o = kuva_o
        self.kuva_v = kuva_v

        # Äänet
        self.hyppy_aani = hyppy_aani

    # --- TASON PÄIVITYS ---
    def paivita_taso(self, taso):
        """
        Aktivoi pelaajan uudet kyvyt tason perusteella.
        """
        if taso >= 3:
            self.tuplahyppy = True
        if taso >= 4:
            self.nopeus = 9
        if taso >= 5:
            self.tuplaluoti = True

    # --- PÄIVITYS ---
    def paivita(self, tasanteet):
        keys = pygame.key.get_pressed()

        # --- Liike ---
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.nopeus
            self.katse = -1
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.nopeus
            self.katse = 1

        # --- Hyppy + Tuplahyppy ---
        if keys[pygame.K_SPACE]:
            # Normaali hyppy
            if not self.ilmassa:
                self.vy = -18
                self.ilmassa = True
                self.tuplahyppy_kaytetty = False
                if self.hyppy_aani:
                    self.hyppy_aani.play()

            # Tuplahyppy ilmassa
            elif self.tuplahyppy and not self.tuplahyppy_kaytetty:
                self.vy = -16
                self.tuplahyppy_kaytetty = True
                if self.hyppy_aani:
                    self.hyppy_aani.play()

        # --- Painovoima ---
        self.vy += 1
        self.rect.y += self.vy

        # --- Lattia ---
        if self.rect.y > 495:
            self.rect.y = 495
            self.vy = 0
            self.ilmassa = False
            self.tuplahyppy_kaytetty = False

        # --- Tasanteet ---
        for tr in tasanteet:
            if self.rect.colliderect(tr) and self.vy > 0:
                if self.rect.bottom - self.vy <= tr.top:
                    self.rect.bottom = tr.top
                    self.vy = 0
                    self.ilmassa = False
                    self.tuplahyppy_kaytetty = False

    # --- PIIRTO ---
    def piirra(self, naytto):
        kuva = self.kuva_o if self.katse == 1 else self.kuva_v
        naytto.blit(kuva, self.rect.topleft)

    # --- RESPAWN ---
    def respawn(self):
        self.rect.x = 400
        self.rect.y = 495
        self.vy = 0
        self.ilmassa = False
        self.tuplahyppy_kaytetty = False
