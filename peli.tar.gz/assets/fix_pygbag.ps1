Write-Host "== Pygbag projektin automaattinen korjaus ==" -ForegroundColor Cyan

# Projektin juuripolku
$root = "C:\xampp\htdocs\peli"

# 1. Poista build-kansiot
Write-Host "Poistetaan vanhat build-kansiot..."
Remove-Item -Recurse -Force "$root\build" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$root\python\build" -ErrorAction SilentlyContinue

# 2. Siirrä kaikki .py-tiedostot python-kansiosta juureen
Write-Host "Siirretään Python-tiedostot juureen..."
Get-ChildItem "$root\python\*.py" | Move-Item -Destination $root -Force -ErrorAction SilentlyContinue

# 3. Poista python-kansio kokonaan
Write-Host "Poistetaan python-kansio..."
Remove-Item -Recurse -Force "$root\python" -ErrorAction SilentlyContinue

# 4. Varmista että assets-kansio on olemassa
if (!(Test-Path "$root\assets")) {
    Write-Host "VAROITUS: assets-kansiota ei löytynyt!" -ForegroundColor Yellow
} else {
    Write-Host "assets-kansio OK"
}

# 5. Listaa projektin lopullinen rakenne
Write-Host "`n== Lopullinen projektirakenne =="
Get-ChildItem $root

Write-Host "`nValmis! Voit nyt ajaa:"
Write-Host "pygbag --build main.py" -ForegroundColor Green
