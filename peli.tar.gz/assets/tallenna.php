<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: text/plain; charset=utf-8");

// --- LUE GET-PARAMETRIT (Python lähettää GET) ---
$nimi    = isset($_GET["nimi"])    ? trim($_GET["nimi"])    : "";
$pisteet = isset($_GET["pisteet"]) ? intval($_GET["pisteet"]) : 0;
$taso    = isset($_GET["taso"])    ? intval($_GET["taso"])    : 0;

// --- ESTÄ TYHJÄT NIMET ---
if ($nimi === "") {
    $nimi = "Player";
}

// --- ESTÄ TÄYSIN TYHJÄT TULOKSET ---
if ($pisteet <= 0 && $taso <= 0) {
    echo "IGNORED";
    exit;
}

// --- LISÄTIEDOT (ei näytetä pelissä) ---
$paiva = date("Y-m-d");
$kello = date("H:i:s");
$ip    = $_SERVER["REMOTE_ADDR"];

// --- TIEDOSTO ---
$tiedosto = "scores.json";

// --- LUE VANHAT PISTEET ---
$data = array();
if (file_exists($tiedosto)) {
    $json = file_get_contents($tiedosto);
    $tmp = json_decode($json, true);
    if (is_array($tmp)) {
        $data = $tmp;
    }
}

// --- LISÄÄ UUSI TULOS ---
$data[] = array(
    "nimi"    => $nimi,
    "pisteet" => $pisteet,
    "taso"    => $taso,
    "paiva"   => $paiva,
    "kello"   => $kello,
    "ip"      => $ip
);

// --- LAJITTELE PISTEIDEN MUKAAN (suurin ensin) ---
usort($data, function($a, $b) {
    return $b["pisteet"] - $a["pisteet"];
});

// --- PIDÄ VAIN TOP 50 ---
$data = array_slice($data, 0, 50);

// --- TALLENNA TAKAISIN ---
file_put_contents($tiedosto, json_encode($data, JSON_PRETTY_PRINT));

// --- VASTAUS ---
echo "OK";
?>
