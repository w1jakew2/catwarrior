<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

// Lue POST-parametrit vanhalla PHP-tyylillä
$nimi    = isset($_POST["nimi"])    ? $_POST["nimi"]    : "";
$pisteet = isset($_POST["pisteet"]) ? $_POST["pisteet"] : 0;
$taso    = isset($_POST["taso"])    ? $_POST["taso"]    : 0;

// Uusi tulos
$uusi = array(
    "nimi"    => $nimi,
    "pisteet" => intval($pisteet),
    "taso"    => intval($taso)
);

$tiedosto = "scores.json";

// Lue vanhat pisteet
$data = array();
if (file_exists($tiedosto)) {
    $json = file_get_contents($tiedosto);
    $tmp = json_decode($json, true);
    if (is_array($tmp)) {
        $data = $tmp;
    }
}

// Lisää uusi tulos
$data[] = $uusi;

// Tallenna takaisin
file_put_contents($tiedosto, json_encode($data, JSON_PRETTY_PRINT));

echo "OK";
?>
