<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

$tiedosto = "scores.json";

if (file_exists($tiedosto)) {
    echo file_get_contents($tiedosto);
} else {
    echo "[]";
}
?>
