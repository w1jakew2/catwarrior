import pygame

def lataa_aani(nimi):
    try:
        return pygame.mixer.Sound(nimi)
    except:
        return None


def lataa_kuva(nimi, koko=None, flip=False):
    try:
        kuva = pygame.image.load(nimi)
        if flip:
            kuva = pygame.transform.flip(kuva, True, False)
        if koko:
            kuva = pygame.transform.scale(kuva, koko)
        return kuva.convert_alpha()
    except:
        # Palautetaan placeholder jos lataus epäonnistuu
        s = pygame.Surface(koko if koko else (50, 50))
        s.fill((200, 0, 200))
        return s


def lataa_resurssit():
    resurssit = {}

    # --- KUVAT ---
    resurssit["tausta"] = lataa_kuva("assets/tausta.jpg", (800, 600), flip=False)
    resurssit["hahmo_o"] = lataa_kuva("assets/catwarrior.png", (55, 55))
    resurssit["hahmo_v"] = lataa_kuva("assets/catwarrior.png", (55, 55), flip=True)
    resurssit["vihu"] = lataa_kuva("assets/vihu.png", (50, 60))
    resurssit["drone"] = lataa_kuva("assets/drone.png", (45, 45))

    # --- ÄÄNET ---
    resurssit["hyppy"] = lataa_aani("assets/hyppy.ogg")
    resurssit["osuma"] = lataa_aani("assets/osuma.ogg")
    resurssit["kolikko"] = lataa_aani("assets/kolikko.ogg")
    resurssit["tuli"] = lataa_aani("assets/laserShoot.ogg")

    return resurssit


def luo_tasanteet():
    return [
        pygame.Rect(100, 450, 180, 25),
        pygame.Rect(450, 350, 180, 25),
        pygame.Rect(250, 200, 250, 25),
    ]
