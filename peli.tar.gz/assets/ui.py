import pygame

# ---------------------------------------------------------
# FONTIT
# ---------------------------------------------------------
def get_fonts():
    otsikko_fontti = pygame.font.SysFont("Arial", 52, bold=True)
    fontti = pygame.font.SysFont("Arial", 28, bold=True)
    pieni_fontti = pygame.font.SysFont("Arial", 20)
    return otsikko_fontti, fontti, pieni_fontti


# ---------------------------------------------------------
# FOOTER
# ---------------------------------------------------------
def piirra_footer(naytto):
    fontti = pygame.font.SysFont("Arial", 18)
    teksti = "© 2026 Jaher-Media. Kaikki oikeudet pidätetään."
    surf = fontti.render(teksti, True, (200, 200, 200))
    naytto.blit(surf, (10, 580))


# ---------------------------------------------------------
# VALIKKO (TOP-LISTA + ALOITUS)
# ---------------------------------------------------------
def piirra_valikko(naytto, tausta, top_lista):
    otsikko_fontti, fontti, pieni_fontti = get_fonts()

    naytto.blit(tausta, (0, 0))

    # PELIN NIMI
    ots = otsikko_fontti.render("CAT WARRIOR", True, (255, 255, 255))
    naytto.blit(ots, (400 - ots.get_width() // 2, 60))

    # TOP 5 LISTA
    ala = fontti.render("TOP 5 PISTEET", True, (255, 255, 0))
    naytto.blit(ala, (400 - ala.get_width() // 2, 150))

    for i, entry in enumerate(top_lista[:5]):
        rivi = f"{i+1}. {entry['nimi']} – {entry['pisteet']} p – Taso {entry['taso']}"
        r = pieni_fontti.render(rivi, True, (255, 255, 255))
        naytto.blit(r, (400 - r.get_width() // 2, 200 + i * 30))

    # OHJETEKSTI
    ohje = fontti.render("Paina ENTER aloittaaksesi", True, (255, 255, 0))
    naytto.blit(ohje, (400 - ohje.get_width() // 2, 500))

    # EI flip() TÄSSÄ — main.py hoitaa sen

    keys = pygame.key.get_pressed()
    if keys[pygame.K_RETURN]:
        return "PELI"

    return "VALIKKO"


# ---------------------------------------------------------
# HUD (Pisteet, elämät, taso)
# ---------------------------------------------------------
def piirra_ui(naytto, pisteet, elamat, taso):
    _, fontti, _ = get_fonts()

    t = fontti.render(
        f"Pisteet: {pisteet} | Elämät: {elamat} | Taso: {taso}",
        True,
        (255, 255, 255)
    )
    naytto.blit(t, (10, 10))


# ---------------------------------------------------------
# BOSS HP-PALKKI
# ---------------------------------------------------------
def piirra_boss_hp(naytto, boss):
    if not boss:
        return

    pygame.draw.rect(naytto, (80, 0, 0), (150, 20, 500, 25))
    hp_leveys = int((boss.hp / 20) * 500)
    pygame.draw.rect(naytto, (255, 0, 0), (150, 20, hp_leveys, 25))

    fontti = pygame.font.SysFont("Arial", 20, bold=True)
    teksti = fontti.render(f"Boss HP: {boss.hp}/20", True, (255, 255, 255))
    naytto.blit(teksti, (400 - teksti.get_width() // 2, 22))


# ---------------------------------------------------------
# TASONOUSUTEKSTI
# ---------------------------------------------------------
def piirra_tasonousu(naytto, teksti):
    if not teksti:
        return

    fontti = pygame.font.SysFont("Arial", 64, bold=True)
    varjo = fontti.render(teksti, True, (0, 0, 0))
    t = fontti.render(teksti, True, (255, 255, 0))

    naytto.blit(varjo, (402 - varjo.get_width() // 2, 202))
    naytto.blit(t, (400 - t.get_width() // 2, 200))


# ---------------------------------------------------------
# GAME OVER (EI SPACE-OHJETTA)
# ---------------------------------------------------------
def piirra_gameover(naytto, tausta, nimi, pisteet, taso):
    otsikko_fontti, fontti, pieni_fontti = get_fonts()

    naytto.blit(tausta, (0, 0))

    ots = otsikko_fontti.render("GAME OVER", True, (255, 80, 80))
    naytto.blit(ots, (400 - ots.get_width() // 2, 120))

    t1 = fontti.render(f"Nimi: {nimi}", True, (255, 255, 255))
    t2 = fontti.render(f"Pisteet: {pisteet}", True, (255, 255, 255))
    t3 = fontti.render(f"Taso: {taso}", True, (255, 255, 255))

    naytto.blit(t1, (400 - t1.get_width() // 2, 260))
    naytto.blit(t2, (400 - t2.get_width() // 2, 290))
    naytto.blit(t3, (400 - t3.get_width() // 2, 320))

    # EI SPACE-OHJETTA — main.py hoitaa automaattisen paluun
